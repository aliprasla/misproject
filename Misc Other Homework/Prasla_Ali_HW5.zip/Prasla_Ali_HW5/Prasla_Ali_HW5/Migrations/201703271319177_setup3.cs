namespace Prasla_Ali_HW5.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class setup3 : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
